package controller.control;

public class Error {
    public   boolean truth;
    public  String errorMessage;


    public Error(boolean truth,String errorMessage){
        this.truth=truth;
        this.errorMessage=errorMessage;
    }
}
