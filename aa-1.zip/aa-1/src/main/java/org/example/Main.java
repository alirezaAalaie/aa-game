package org.example;

import controller.Controller;

public class Main {
    public static void main(String[] args) throws Exception {

        new Controller ().run (args);

    }
}